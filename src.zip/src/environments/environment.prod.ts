export const environment = {
  production: true,
  apiKey: "AIzaSyAXTEf4qr4zyhKlZ7xxTYwKSQjEAj-SSCA",
  dbUrl: "https://ang-shop-9d30a-default-rtdb.europe-west1.firebasedatabase.app/"
};
